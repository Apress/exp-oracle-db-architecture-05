drop user least_privs;

create user least_privs identified by least_privs;
grant create session to least_privs;
connect least_privs/least_privs
declare
  l_string varchar2(255);
  l_dummy  number;
begin
   l_dummy := dbms_utility.get_parameter_value
   ( 'background_dump_dest', l_dummy, l_string );
   dbms_output.put_line( 'background: ' || l_string );
   l_dummy := dbms_utility.get_parameter_value
   ( 'user_dump_dest', l_dummy, l_string );
   dbms_output.put_line( 'user:       ' || l_string );
end;
/

