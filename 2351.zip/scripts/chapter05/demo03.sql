 select paddr, name, description
  from v$bgprocess
 order by paddr desc
/

