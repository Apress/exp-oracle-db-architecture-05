select * from dual where null=null;
select * from dual where null <> null;
select * from dual where null is null;

