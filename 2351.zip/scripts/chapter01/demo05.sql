create table id_table
( id_name  varchar2(30) primary key,
  id_value number );
insert into id_table values ( 'MY_KEY', 0 );
commit;
update id_table
   set id_value = id_value+1
 where id_name = 'MY_KEY';
select id_value
  from id_table
 where id_name = 'MY_KEY';
commit;
set transaction isolation level serializable;
 
update id_table
   set id_value = id_value+1
 where id_name = 'MY_KEY';
 
select id_value
  from id_table
 where id_name = 'MY_KEY';

PROMPT in another session execute:
PROMPT set transaction isolation level serializable;;
PROMPT  
PROMPT update id_table
PROMPT    set id_value = id_value+1
PROMPT  where id_name = 'MY_KEY';;
pause

commit; 
