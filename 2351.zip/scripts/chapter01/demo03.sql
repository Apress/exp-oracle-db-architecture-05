connect / as sysdba
grant execute on dbms_flashback to scott;

connect scott/tiger

variable SCN number
exec :scn := sys.dbms_flashback.get_system_change_number
print scn
select count(*) from emp;
delete from emp;
select count(*) from emp;
select count(*) from emp AS OF SCN :scn;
commit;
select *
 from (select count(*) from emp),
      (select count(*) from emp as of scn :scn)
/
select *
 from (select count(*) from emp),
      (select count(*) from emp as of scn :scn)
/
alter table emp enable row movement; 
flashback table emp to scn :scn;
select *
 from (select count(*) from emp),
      (select count(*) from emp as of scn :scn)
/
