select segment_name, segment_type
  from user_segments;
create table t ( x int primary key, y clob, z blob );
select segment_name, segment_type
  from user_segments;

