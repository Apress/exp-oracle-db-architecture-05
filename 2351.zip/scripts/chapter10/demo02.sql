create table t ( x int, y char(50) ) tablespace MSSM;



begin
    for i in 1 .. 100000
    loop
        insert into t values ( i, 'x' );
    end loop;
    commit;
end;
/
exit;


create table t ( x int, y char(50) ) 
storage( freelists 5 ) tablespace MSSM;

alter table t storage ( FREELISTS 5 );


create tablespace assm
datafile size 1m autoextend on next 1m
segment space management auto;

create table t ( x int, y char(50) ) tablespace ASSM;

