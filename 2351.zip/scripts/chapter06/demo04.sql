drop table dept;
create table dept
(deptno, dname, loc, data,
 constraint dept_pk primary key(deptno)
)
as
select deptno, dname, loc, rpad('*',3500,'*')
  from scott.dept;
select deptno, dname,
       dbms_rowid.rowid_block_number(rowid) blockno,
           ora_rowscn
  from dept;
update dept
   set dname = lower(dname)
 where deptno = 10;
commit;
select deptno, dname,
       dbms_rowid.rowid_block_number(rowid) blockno,
           ora_rowscn
  from dept;
drop table dept;
create table dept
(deptno, dname, loc, data,
 constraint dept_pk primary key(deptno)
)
ROWDEPENDENCIES
as
select deptno, dname, loc, rpad('*',3500,'*')
  from scott.dept;
select deptno, dname,
       dbms_rowid.rowid_block_number(rowid) blockno,
           ora_rowscn
  from dept;
update dept
   set dname = lower(dname)
 where deptno = 10;
commit;
select deptno, dname,
       dbms_rowid.rowid_block_number(rowid) blockno,
           ora_rowscn
  from dept;

