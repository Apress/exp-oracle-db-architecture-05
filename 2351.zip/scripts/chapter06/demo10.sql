create table t ( x int ) maxtrans 2;
insert into t select rownum from all_users;
commit;
select distinct dbms_rowid.rowid_block_number(rowid) from t;
update t set x = 1 where x = 1;

prompt in another session update t set x = 2 where x = 2;;
prompt in yet another session update t set x = 3 where x = 3;;

