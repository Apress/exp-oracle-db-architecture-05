select session_id sid, owner, name, type, 
    mode_held held, mode_requested request
from dba_ddl_locks;
create or replace procedure p as begin null; end;
/
exec p
select session_id sid, owner, name, type,
       mode_held held, mode_requested request
  from dba_ddl_locks
/
alter procedure p compile;
select session_id sid, owner, name, type,
       mode_held held, mode_requested request
  from dba_ddl_locks
/
 

