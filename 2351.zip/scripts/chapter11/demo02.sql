create table t
as
select * from all_objects;
create index t_idx on
t(owner,object_type,object_name);
analyze index t_idx validate structure;
create table idx_stats
as
select 'noncompressed' what, a.*
  from index_stats a;



drop index t_idx;
create index t_idx on
t(owner,object_type,object_name)
compress &1;
analyze index t_idx validate structure;
insert into idx_stats
select 'compress &1', a.*
 from index_stats a;



select what, height, lf_blks, br_blks,
       btree_space, opt_cmpr_count, opt_cmpr_pctsave
  from idx_stats
/
