set autotrace traceonly explain
select owner, object_type
  from t
 where owner between 'T' and 'Z'
   and object_type is not null
 order by owner DESC, object_type DESC;
select owner, object_type
  from t
 where owner between 'T' and 'Z'
   and object_type is not null
 order by owner DESC, object_type ASC;
create index desc_t_idx on t(owner desc,object_type asc);
exec dbms_stats.gather_index_stats( user, 'DESC_T_IDX' );
select owner, object_type
  from t
 where owner between 'T' and 'Z'
   and object_type is not null
 order by owner DESC, object_type ASC;
 

