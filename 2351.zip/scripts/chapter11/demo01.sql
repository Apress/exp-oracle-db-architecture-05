select index_name, blevel, num_rows
from user_indexes
where table_name = 'BIG_TABLE';
select id from big_table where id = 42;
select id from big_table where id = 12345;
select id from big_table where id = 1234567;

