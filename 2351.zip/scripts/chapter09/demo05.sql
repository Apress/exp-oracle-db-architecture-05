create table t
( x char(2000),
  y char(2000),
  z char(2000)
)
/
set autotrace traceonly statistics
insert into t
select 'x', 'y', 'z'
  from all_objects
 where rownum <= 500;
commit;
select *
  from t;
select *
  from t;
set autotrace off

