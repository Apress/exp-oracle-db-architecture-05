select log_mode from v$database;
@mystat "redo size"
create table t
as
select * from all_objects;
@mystat2
drop table t;
@mystat "redo size"
create table t
NOLOGGING
as
select * from all_objects;
@mystat2
create index t_idx on t(object_name);
@mystat "redo size"
alter index t_idx rebuild;
@mystat2
alter index t_idx nologging;
@mystat "redo size"
alter index t_idx rebuild;
@mystat2

