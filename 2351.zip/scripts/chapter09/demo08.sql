create undo tablespace undo_small
datafile size 2m
autoextend off
/
alter system set undo_tablespace = undo_small;

create table t
as
select *
  from all_objects
 order by dbms_random.random;
alter table t add constraint t_pk primary key(object_id)
/
exec dbms_stats.gather_table_stats( user, 'T', cascade=> true );
begin
    for x in ( select rowid rid from t )
    loop
        update t set object_name = lower(object_name) where rowid = x.rid;
        commit;
    end loop;
end;
/

/*
to be run in the other session
*/
doc
declare
    cursor c is
    select /*+ first_rows */ object_name
      from t
     order by object_id;

    l_object_name t.object_name%type;
    l_rowcnt      number := 0;
begin
    open c;
    loop
        fetch c into l_object_name;
        exit when c%notfound;
        dbms_lock.sleep( 0.01 );
        l_rowcnt := l_rowcnt+1;
    end loop;
    close c;
exception
    when others then
        dbms_output.put_line( 'rows fetched = ' || l_rowcnt );
        raise;
end;
/
#
