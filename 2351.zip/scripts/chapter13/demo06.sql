CREATE TABLE composite_example
( range_key_column   date,
  hash_key_column    int,
  data               varchar2(20)
)
PARTITION BY RANGE (range_key_column)
subpartition by hash(hash_key_column) subpartitions 2
(
PARTITION part_1
     VALUES LESS THAN(to_date('01/01/2005','dd/mm/yyyy'))
     (subpartition part_1_sub_1,
      subpartition part_1_sub_2
     ),
PARTITION part_2
    VALUES LESS THAN(to_date('01/01/2006','dd/mm/yyyy'))
    (subpartition part_2_sub_1,
     subpartition part_2_sub_2
    )
)
/
CREATE TABLE composite_range_list_example
( range_key_column   date,
  code_key_column    int,
  data               varchar2(20)
)
PARTITION BY RANGE (range_key_column)
subpartition by list(code_key_column)
(
PARTITION part_1
     VALUES LESS THAN(to_date('01/01/2005','dd/mm/yyyy'))
     (subpartition part_1_sub_1 values( 1, 3, 5, 7 ),
      subpartition part_1_sub_2 values( 2, 4, 6, 8 )
     ),
PARTITION part_2
    VALUES LESS THAN(to_date('01/01/2006','dd/mm/yyyy'))
    (subpartition part_2_sub_1 values ( 1, 3 ),
     subpartition part_2_sub_2 values ( 5, 7 ),
     subpartition part_2_sub_3 values ( 2, 4, 6, 8 )
    )
)
/
