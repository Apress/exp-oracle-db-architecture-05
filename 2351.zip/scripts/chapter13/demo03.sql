CREATE TABLE range_example
( range_key_column date ,
  data             varchar2(20)
)
PARTITION BY RANGE (range_key_column)
( PARTITION part_1 VALUES LESS THAN
       (to_date('01/01/2005','dd/mm/yyyy')),
  PARTITION part_2 VALUES LESS THAN
       (to_date('01/01/2006','dd/mm/yyyy'))
)
/
insert into range_example
( range_key_column, data )
values
( to_date( '15/12/2007 00:00:00',
           'dd/mm/yyyy hh24:mi:ss' ),
  'application data...' );

drop table range_example;


CREATE TABLE range_example
( range_key_column date ,
  data             varchar2(20)
)
PARTITION BY RANGE (range_key_column)
( PARTITION part_1 VALUES LESS THAN
       (to_date('01/01/2005','dd/mm/yyyy')),
  PARTITION part_2 VALUES LESS THAN
       (to_date('01/01/2006','dd/mm/yyyy')),
  PARTITION part_3 VALUES LESS THAN
       (MAXVALUE)
)
/
