select dname
  from SYS_SQLLDR_X_EXT_DEPT
/
select deptno
  from SYS_SQLLDR_X_EXT_DEPT
/
alter table SYS_SQLLDR_X_EXT_DEPT
project column referenced
/
select dname
  from SYS_SQLLDR_X_EXT_DEPT
/
select deptno
  from SYS_SQLLDR_X_EXT_DEPT
/

