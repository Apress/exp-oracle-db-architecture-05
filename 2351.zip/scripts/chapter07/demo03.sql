create table t ( x int );
insert into t values ( 1 );
commit;
exec dbms_stats.gather_table_stats( user, 'T' );
alter session set sql_trace=true;
select * from t;
update t t1 set x = x+1;
update t t2 set x = x+1;

