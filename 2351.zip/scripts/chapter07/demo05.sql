create table t ( x int, y int );
insert into t values ( 1, 1 );
commit;
create or replace trigger t_bufer
before update on t for each row
begin
	dbms_output.put_line( 'fired' );
end;
/
set serveroutput on
update t set x = x+1;
prompt in another session:
prompt set serveroutput on
prompt update t set x = x+1 where y > 0;;
prompt and then come back and hit enter
pause
commit;
