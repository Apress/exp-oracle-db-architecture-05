create table t ( x int );
insert into t values ( 1 );
exec dbms_stats.gather_table_stats( user, 'T' );
select * from t;
alter session set isolation_level=serializable;
set autotrace on statistics
select * from t;
prompt in another session do this:
prompt begin
prompt     for i in 1 .. 10000
prompt     loop
prompt         update t set x = x+1;;
prompt         commit;;
prompt     end loop;;
prompt end;;
prompt /
pause
select * from t;

