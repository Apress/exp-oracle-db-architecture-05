
create table t  ( x int unique );
insert into t values ( 1 );
insert into t values ( 2 );
update t set x = x+1;

