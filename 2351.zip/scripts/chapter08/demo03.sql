create table p
( pk  int primary key )
/
create table c
( fk  constraint c_fk
      references p(pk)
      deferrable
      initially immediate
)
/
insert into p values ( 1 );
insert into c values ( 1 );

commit;

update p set pk = 2;
set constraint c_fk deferred;
update p set pk = 2;
set constraint c_fk immediate;
update c set fk = 2;
set constraint c_fk immediate;
commit;
