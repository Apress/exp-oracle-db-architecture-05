show parameter sga_target
select component, granule_size from v$sga_dynamic_components;
alter system set sga_target = 1512m scope=spfile;
startup force
select component, granule_size from v$sga_dynamic_components;

