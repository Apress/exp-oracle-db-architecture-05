create table t as select * from all_objects;
exec dbms_stats.gather_table_stats( user, 'T' );

alter session set workarea_size_policy=manual;
alter session set sort_area_size = 65536;
set termout off
select * from t order by 1, 2, 3, 4;
set termout on
alter session set sort_area_size=1048576;
set termout off
select * from t order by 1, 2, 3, 4;
set termout on
alter session set sort_area_size=1073741820;
set termout off
select * from t order by 1, 2, 3, 4;
set termout on

