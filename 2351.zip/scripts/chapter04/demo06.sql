alter system set log_buffer=1 scope=spfile; 
startup force
show parameter log_buffer
 

