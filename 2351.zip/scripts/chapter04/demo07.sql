select tch, file#, dbablk,
       case when obj = 4294967295
            then 'rbs/compat segment'
            else (select max( '('||object_type||') ' ||
                              owner || '.' || object_name  ) ||
                         decode( count(*), 1, '', ' maybe!' )
                    from dba_objects
                   where data_object_id = X.OBJ )
        end what
  from (
select tch, file#, dbablk, obj
  from x$bh
 where state <> 0
 order by tch desc
       ) x
 where rownum <= 5
/

