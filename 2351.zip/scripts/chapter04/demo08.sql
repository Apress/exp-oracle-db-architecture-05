 select data_object_id, count(*)
   from dba_objects
  where data_object_id is not null
  group by data_object_id
 having count(*) > 1;

