select tch, file#, dbablk, DUMMY
  from x$bh, (select dummy from dual)
 where obj = (select data_object_id
                from dba_objects
               where object_name = 'DUAL'
                 and data_object_id is not null)
/
exec dbms_lock.sleep(3.2);
/
exec dbms_lock.sleep(3.2);
/
exec dbms_lock.sleep(3.2);
/

